print("""
                        ___________________________________________________________
                        |                        GOMOMMY                           |
                        |__________________________________________________________|
                        

                        COM.COM IS AVAILIBLE FOR PURCHASE! PLEASE EMAIL [dummy] FOR
                        INFORMATION ON HOW MUCH THIS DOMAIN IS!!!!!111!!1!!!!!11111!
                        
                         
                        """)