cmd = ""
print("welcome to RiptideImages.com. Please type any picture that is availible right now. (type esc to quit)")
while cmd != "esc":
    cmd = input("AOST/kBrowse/search/ri/: ")
    if cmd == "help":
        print("images that are availible:")
        print("\nbomb ", "laptop ", "basketball \n")
    if cmd == "bomb":
        #from ../picts import bomb
        pass
    if cmd == "laptop":
        #from ../picts import laptop
        pass
    if cmd == "basketball":
        #from ../picts import basketball 
        pass